package com.tabkeyboard.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothHidDevice;
import android.bluetooth.BluetoothHidDeviceAppSdpSettings;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Turns this phone into a Bluetooth keyboard for another device (e.g. an iKall tablet).
 * Type in the box on the phone and the text appears on the tablet.
 */
@SuppressLint("MissingPermission")
public class MainActivity extends Activity {

    private static final int REPORT_ID = 1;
    private static final int SHIFT = 0x0200; // left shift modifier (0x02) << 8

    private static final int KEY_ENTER = 0x28;
    private static final int KEY_ESC = 0x29;
    private static final int KEY_BACKSPACE = 0x2A;
    private static final int KEY_TAB = 0x2B;
    private static final int KEY_DELETE = 0x4C;
    private static final int KEY_RIGHT = 0x4F;
    private static final int KEY_LEFT = 0x50;
    private static final int KEY_DOWN = 0x51;
    private static final int KEY_UP = 0x52;

    // Standard HID keyboard report descriptor (with Report ID 1)
    private static final byte[] DESCRIPTOR = new byte[]{
            (byte) 0x05, (byte) 0x01,
            (byte) 0x09, (byte) 0x06,
            (byte) 0xA1, (byte) 0x01,
            (byte) 0x85, (byte) 0x01,
            (byte) 0x05, (byte) 0x07,
            (byte) 0x19, (byte) 0xE0,
            (byte) 0x29, (byte) 0xE7,
            (byte) 0x15, (byte) 0x00,
            (byte) 0x25, (byte) 0x01,
            (byte) 0x75, (byte) 0x01,
            (byte) 0x95, (byte) 0x08,
            (byte) 0x81, (byte) 0x02,
            (byte) 0x95, (byte) 0x01,
            (byte) 0x75, (byte) 0x08,
            (byte) 0x81, (byte) 0x01,
            (byte) 0x95, (byte) 0x05,
            (byte) 0x75, (byte) 0x01,
            (byte) 0x05, (byte) 0x08,
            (byte) 0x19, (byte) 0x01,
            (byte) 0x29, (byte) 0x05,
            (byte) 0x91, (byte) 0x02,
            (byte) 0x95, (byte) 0x01,
            (byte) 0x75, (byte) 0x03,
            (byte) 0x91, (byte) 0x01,
            (byte) 0x95, (byte) 0x06,
            (byte) 0x75, (byte) 0x08,
            (byte) 0x15, (byte) 0x00,
            (byte) 0x25, (byte) 0x65,
            (byte) 0x05, (byte) 0x07,
            (byte) 0x19, (byte) 0x00,
            (byte) 0x29, (byte) 0x65,
            (byte) 0x81, (byte) 0x00,
            (byte) 0xC0
    };

    private BluetoothAdapter adapter;
    private BluetoothHidDevice hid;
    private BluetoothDevice host;
    private boolean registered = false;
    private boolean muted = false;

    private TextView status;
    private LinearLayout deviceBox;
    private EditText input;

    private final ExecutorService sender = Executors.newSingleThreadExecutor();

    private final BluetoothHidDevice.Callback callback = new BluetoothHidDevice.Callback() {
        @Override
        public void onAppStatusChanged(BluetoothDevice pluggedDevice, boolean reg) {
            registered = reg;
            if (reg) {
                setStatus("Keyboard is ON. Pair with your tablet, then tap the tablet name below.");
                refreshDevices();
            } else {
                setStatus("Keyboard stopped.");
            }
        }

        @Override
        public void onConnectionStateChanged(BluetoothDevice device, int state) {
            if (state == BluetoothProfile.STATE_CONNECTED) {
                host = device;
                setStatus("Connected to " + nameOf(device) + ". Type below.");
            } else if (state == BluetoothProfile.STATE_CONNECTING) {
                setStatus("Connecting to " + nameOf(device) + "...");
            } else if (state == BluetoothProfile.STATE_DISCONNECTED) {
                if (host != null && host.equals(device)) {
                    host = null;
                }
                setStatus("Disconnected. Tap your tablet name to connect.");
            }
        }
    };

    private final BluetoothProfile.ServiceListener listener = new BluetoothProfile.ServiceListener() {
        @Override
        public void onServiceConnected(int profile, BluetoothProfile proxy) {
            if (profile == BluetoothProfile.HID_DEVICE) {
                hid = (BluetoothHidDevice) proxy;
                registerKeyboard();
            }
        }

        @Override
        public void onServiceDisconnected(int profile) {
            if (profile == BluetoothProfile.HID_DEVICE) {
                hid = null;
                registered = false;
                host = null;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
    }

    // ---------------------------------------------------------------- UI

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private Button btn(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    private Button keyBtn(String label, final int code) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(12);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(dp(2), 0, dp(2), 0);
        b.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        b.setOnClickListener(v -> tap(code >> 8, code & 0xFF));
        return b;
    }

    private void buildUi() {
        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(16));
        sv.addView(root);

        TextView title = new TextView(this);
        title.setText("Tab Keyboard");
        title.setTextSize(24);
        root.addView(title);

        status = new TextView(this);
        status.setText("Step 1: tap Start keyboard.");
        status.setPadding(0, dp(8), 0, dp(8));
        root.addView(status);

        root.addView(btn("1. Start keyboard", v -> startKeyboard()));
        root.addView(btn("2. Make phone visible to tablet", v -> makeDiscoverable()));
        root.addView(btn("Open Bluetooth settings", v ->
                startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS))));
        root.addView(btn("Disconnect", v -> {
            if (hid != null && host != null) {
                hid.disconnect(host);
            }
        }));

        deviceBox = new LinearLayout(this);
        deviceBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(deviceBox);

        input = new EditText(this);
        input.setHint("Type here - text goes to the tablet");
        input.setMinLines(3);
        input.setInputType(InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        input.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (muted) {
                    return;
                }
                for (int i = 0; i < before; i++) {
                    tap(0, KEY_BACKSPACE);
                }
                for (int i = 0; i < count; i++) {
                    int code = map(s.charAt(start + i));
                    if (code >= 0) {
                        tap(code >> 8, code & 0xFF);
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable e) {
                if (!muted && e.length() > 60) {
                    muted = true;
                    e.clear();
                    muted = false;
                }
            }
        });
        input.setOnKeyListener((v, keyCode, event) -> {
            if (keyCode == KeyEvent.KEYCODE_DEL
                    && event.getAction() == KeyEvent.ACTION_DOWN
                    && input.length() == 0) {
                tap(0, KEY_BACKSPACE);
            }
            return false;
        });
        root.addView(input);

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.addView(keyBtn("Esc", KEY_ESC));
        row1.addView(keyBtn("Tab", KEY_TAB));
        row1.addView(keyBtn("Bksp", KEY_BACKSPACE));
        row1.addView(keyBtn("Del", KEY_DELETE));
        row1.addView(keyBtn("Enter", KEY_ENTER));
        root.addView(row1);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.addView(keyBtn("\u2190", KEY_LEFT));
        row2.addView(keyBtn("\u2191", KEY_UP));
        row2.addView(keyBtn("\u2193", KEY_DOWN));
        row2.addView(keyBtn("\u2192", KEY_RIGHT));
        root.addView(row2);

        root.addView(btn("Clear box", v -> {
            muted = true;
            input.setText("");
            muted = false;
        }));

        setContentView(sv);
    }

    private void setStatus(String s) {
        if (status != null) {
            status.setText(s);
        }
    }

    private String nameOf(BluetoothDevice d) {
        String n = null;
        try {
            n = d.getName();
        } catch (Exception ignored) {
        }
        if (n == null) {
            n = d.getAddress();
        }
        return n;
    }

    private void refreshDevices() {
        deviceBox.removeAllViews();
        if (adapter == null) {
            return;
        }
        TextView t = new TextView(this);
        t.setText("Paired devices - tap your iKall tablet:");
        t.setPadding(0, dp(8), 0, dp(4));
        deviceBox.addView(t);
        Set<BluetoothDevice> bonded = adapter.getBondedDevices();
        if (bonded == null || bonded.isEmpty()) {
            TextView none = new TextView(this);
            none.setText("(none yet - pair the phone from the tablet's Bluetooth settings first)");
            deviceBox.addView(none);
            return;
        }
        for (BluetoothDevice d : bonded) {
            final BluetoothDevice dev = d;
            deviceBox.addView(btn(nameOf(dev), v -> connectTo(dev)));
        }
    }

    // ---------------------------------------------------------------- Bluetooth

    private void startKeyboard() {
        if (Build.VERSION.SDK_INT >= 31) {
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
                    || checkSelfPermission(Manifest.permission.BLUETOOTH_ADVERTISE) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{
                        Manifest.permission.BLUETOOTH_CONNECT,
                        Manifest.permission.BLUETOOTH_ADVERTISE}, 1);
                return;
            }
        }
        begin();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        boolean ok = grantResults.length > 0;
        for (int r : grantResults) {
            if (r != PackageManager.PERMISSION_GRANTED) {
                ok = false;
            }
        }
        if (ok) {
            begin();
        } else {
            setStatus("Bluetooth permission was denied. Allow it and tap Start keyboard again.");
        }
    }

    private void begin() {
        BluetoothManager bm = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        adapter = bm == null ? null : bm.getAdapter();
        if (adapter == null) {
            setStatus("This phone has no Bluetooth.");
            return;
        }
        if (!adapter.isEnabled()) {
            setStatus("Turn Bluetooth ON, then tap Start keyboard again.");
            return;
        }
        if (hid != null) {
            registerKeyboard();
            return;
        }
        boolean ok = adapter.getProfileProxy(this, listener, BluetoothProfile.HID_DEVICE);
        if (!ok) {
            setStatus("This phone does not support Bluetooth keyboard mode.");
        }
    }

    private void registerKeyboard() {
        if (hid == null) {
            return;
        }
        if (registered) {
            refreshDevices();
            return;
        }
        BluetoothHidDeviceAppSdpSettings sdp = new BluetoothHidDeviceAppSdpSettings(
                "Tab Keyboard",
                "Phone as keyboard",
                "TabKeyboard",
                BluetoothHidDevice.SUBCLASS1_KEYBOARD,
                DESCRIPTOR);
        boolean ok = hid.registerApp(sdp, null, null, getMainExecutor(), callback);
        if (!ok) {
            setStatus("Could not start keyboard mode on this phone.");
        }
    }

    private void makeDiscoverable() {
        Intent i = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
        i.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300);
        startActivity(i);
    }

    private void connectTo(BluetoothDevice dev) {
        if (hid == null || !registered) {
            setStatus("Tap Start keyboard first.");
            return;
        }
        setStatus("Connecting to " + nameOf(dev) + "...");
        hid.connect(dev);
    }

    // ---------------------------------------------------------------- Typing

    private void tap(final int modifier, final int key) {
        final BluetoothHidDevice h = hid;
        final BluetoothDevice d = host;
        if (h == null || d == null) {
            setStatus("Not connected. Tap your tablet name in the list.");
            return;
        }
        sender.execute(() -> {
            try {
                byte[] down = new byte[]{(byte) modifier, 0, (byte) key, 0, 0, 0, 0, 0};
                h.sendReport(d, REPORT_ID, down);
                Thread.sleep(8);
                h.sendReport(d, REPORT_ID, new byte[8]);
                Thread.sleep(8);
            } catch (Exception ignored) {
            }
        });
    }

    /** Returns (modifier << 8) | usage, or -1 if the character is not supported. */
    private int map(char c) {
        if (c >= 'a' && c <= 'z') return 0x04 + (c - 'a');
        if (c >= 'A' && c <= 'Z') return SHIFT | (0x04 + (c - 'A'));
        if (c >= '1' && c <= '9') return 0x1E + (c - '1');
        if (c == '0') return 0x27;
        switch (c) {
            case ' ': return 0x2C;
            case '\n': return KEY_ENTER;
            case '\t': return KEY_TAB;
            case '!': return SHIFT | 0x1E;
            case '@': return SHIFT | 0x1F;
            case '#': return SHIFT | 0x20;
            case '$': return SHIFT | 0x21;
            case '%': return SHIFT | 0x22;
            case '^': return SHIFT | 0x23;
            case '&': return SHIFT | 0x24;
            case '*': return SHIFT | 0x25;
            case '(': return SHIFT | 0x26;
            case ')': return SHIFT | 0x27;
            case '-': return 0x2D;
            case '_': return SHIFT | 0x2D;
            case '=': return 0x2E;
            case '+': return SHIFT | 0x2E;
            case '[': return 0x2F;
            case '{': return SHIFT | 0x2F;
            case ']': return 0x30;
            case '}': return SHIFT | 0x30;
            case '\\': return 0x31;
            case '|': return SHIFT | 0x31;
            case ';': return 0x33;
            case ':': return SHIFT | 0x33;
            case '\'': return 0x34;
            case '"': return SHIFT | 0x34;
            case '`': return 0x35;
            case '~': return SHIFT | 0x35;
            case ',': return 0x36;
            case '<': return SHIFT | 0x36;
            case '.': return 0x37;
            case '>': return SHIFT | 0x37;
            case '/': return 0x38;
            case '?': return SHIFT | 0x38;
            default: return -1;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            if (hid != null) {
                hid.unregisterApp();
                if (adapter != null) {
                    adapter.closeProfileProxy(BluetoothProfile.HID_DEVICE, hid);
                }
            }
        } catch (Exception ignored) {
        }
        sender.shutdownNow();
    }
}
